/* Olá, galera do samp então eu vim trazer uma inlude que verifica se o Jogador
está conectado no Android, queria dizer que quem fez o include inicialmente
foi o Jekmant más quando baixei esse include estava extremamente bugado
e vir que esta difícil de achar ele no google agora, então decide trazer ele mais
otimizado e sem bugs para vocês, caso algum de vocês forem postar esse
include em exato deixem os créditos do Jekmant e o meus créditos também. */

/* Vocês podem ta usando esse código aqui caso vocês queram que o Jogador
receba uma mensagem ao spawnar. */

/* Caso vocês tenham uma variável Ex: ( new EstaNoAndroid[MAX_PLAYERS]; ) ou
então outra da sua preferência vocês podem está colocando ela na if estou falando
isso por que alguns servidores usam isso por que diferencia o Android para o PC
Ex: o inventário de Android vai ser em dialog e o Inventário de PC vai ser em textdraw
então tem alguns servidores que usa esse Ex de variável. lembrando não estou falando
que se você ter essa variável vai ter a dialog ou textdraw é claro que você tem que criar
o código. */

public OnPlayerSpawn(playerid)
{
    if(PlayerAndroidInfo[playerid][TaNoAndroid] == true)
    {
        SendClientMessage(playerid, -1,"Voce foi identificado como jogador Android");
        EstaNoAndroid[playerid] = true; //Se for Android
        return 1;
    }
    
    /* Vocês podem ta aproveitando e usando o "false" pra identificar o jogador de PC
    ja que o false não verifica o android, então se o player não for android vai ser dado
    como "false" então vocês podem tá aproveitando e usando o "false" para identificar
    um jogador de PC. */
    
    if(PlayerAndroidInfo[playerid][TaNoAndroid] == false)
    {
        SendClientMessage(playerid, -1,"Voce foi identificado como jogador PC");
        EstaNoAndroid[playerid] = false; //Caso você queira identificar como PC
        return 1;
    }
    return 1;
}

/* Bom é só isso espero que vocês façam bom aproveito do sistema é uma
boa implementação no seu servidor já é uma ajuda para o player não precisar
escolher em uma dialog se ele é Android ou PC esse sistema ja escolhe
automaticamente. */

Atenciosamente, Walkerxinho7
Discord, Walkerxinho7#9124 me chama caso precise de ajuda